#!/usr/bin/env python3
# Language: python
# Created: 2025-09-23 12:44:02

#!/usr/bin/env python3
"""
BankBranchLocator.com Scraper

Purpose:
  - Crawl the BankBranchLocator website to compile a spreadsheet of the top banks of each US state
  - Extract the following fields per branch:
      Bank Name, Branch Name, Office Address, City or Town, State & County, Zip Code, Phone Number, Online Bank

Notes:
  - This script is written to be resilient to minor HTML structure differences across pages
  - It uses request retry logic, polite delays, and multiple parsing fallbacks
  - If a bank appears to be online-only (no physical branches discovered), Online Bank will be set to "Yes"

Usage:
  pip install requests beautifulsoup4 lxml openpyxl
  python bankbranchlocator_scraper.py --output banks_all_states.csv --xlsx banks_all_states.xlsx --delay 1.0

Command-line arguments:
  --max-states: Limit number of states to scrape (for testing)
  --max-banks:  Limit number of banks per state (for testing)
  --delay:      Seconds to sleep between requests (default 1.0)
  --timeout:    HTTP request timeout seconds (default 20)
  --output:     CSV output file path
  --xlsx:       Optional XLSX output path (requires openpyxl)

Disclaimer:
  - The target website structure may change. This scraper includes best-effort fallbacks and logging
  - Always comply with the site's robots.txt and terms of use. Use responsible request rates
"""

import argparse
import csv
import logging
import re
import sys
import time
from dataclasses import dataclass
from typing import Iterable, List, Dict, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

BASE_URL = "https://www.bankbranchlocator.com/"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0 Safari/537.36"
}


@dataclass
class BranchRecord:
    bank_name: str
    branch_name: str
    office_address: str
    city_town: str
    state_county: str
    zip_code: str
    phone_number: str
    online_bank: str  # "Yes" or "No"

    def to_row(self) -> List[str]:
        return [
            self.bank_name,
            self.branch_name,
            self.office_address,
            self.city_town,
            self.state_county,
            self.zip_code,
            self.phone_number,
            self.online_bank,
        ]


class Scraper:
    def __init__(self, delay: float = 1.0, timeout: int = 20):
        self.s = requests.Session()
        self.s.headers.update(HEADERS)
        self.delay = delay
        self.timeout = timeout

    def get(self, url: str) -> Optional[BeautifulSoup]:
        for attempt in range(5):
            try:
                logging.debug(f"GET {url} (attempt {attempt+1})")
                r = self.s.get(url, timeout=self.timeout)
                if r.status_code == 200:
                    time.sleep(self.delay)
                    return BeautifulSoup(r.text, "lxml")
                logging.warning(f"Non-200 status {r.status_code} for {url}")
            except requests.RequestException as e:
                logging.warning(f"Request error {e} for {url}")
            time.sleep(min(self.delay * (attempt + 1), 5))
        logging.error(f"Failed to GET after retries: {url}")
        return None

    # --------------- Discovery helpers ---------------
    def discover_state_links(self) -> List[Tuple[str, str]]:
        """Attempt to discover links for each US state from the homepage or a states index.
        Returns a list of (state_name, state_url).
        """
        soup = self.get(BASE_URL)
        if not soup:
            return []

        state_links: List[Tuple[str, str]] = []

        # Try common patterns: sections that list states
        candidates = []
        candidates.extend(soup.select('a[href*="/banks-in-"]'))
        candidates.extend(soup.select('a[href*="/banks/" i]'))
        candidates.extend(soup.select('a[href*="/state/"]'))
        candidates.extend(soup.select('a[href*="/banks-in/"]'))

        # Fallback: find all anchors that look like "Banks in State"
        if not candidates:
            for a in soup.find_all('a'):
                txt = (a.get_text(strip=True) or '').lower()
                if 'banks in' in txt:
                    candidates.append(a)

        seen = set()
        for a in candidates:
            href = a.get('href') or ''
            name = a.get_text(strip=True)
            if not href or not name:
                continue
            # Filter out obvious non-state links
            if len(name) > 2 and any(us in name for us in [
                'Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming'
            ]):
                url = urljoin(BASE_URL, href)
                key = (name, url)
                if key not in seen:
                    seen.add(key)
                    state_links.append((name, url))

        # Deduplicate by URL
        by_url = {}
        for name, url in state_links:
            by_url[url] = name
        normalized = [(by_url[u], u) for u in sorted(by_url.keys())]
        logging.info(f"Discovered {len(normalized)} state links")
        return normalized

    def discover_top_banks_on_state(self, state_url: str, max_banks: Optional[int] = None) -> List[Tuple[str, str]]:
        """Return list of (bank_name, bank_url) for a given state page.
        Tries multiple selectors likely to capture a Top Banks list.
        """
        soup = self.get(state_url)
        if not soup:
            return []

        banks: List[Tuple[str, str]] = []

        # Try ordered/unordered list sections that might contain bank links
        selectors = [
            'section a[href*="/bank/"]',
            'div a[href*="/bank/"]',
            'ul a[href*="/bank/"]',
            'ol a[href*="/bank/"]',
            'a[href*="/bank-"]',
        ]
        for sel in selectors:
            for a in soup.select(sel):
                href = a.get('href') or ''
                text = a.get_text(strip=True) or ''
                if not href or not text:
                    continue
                if '/bank' in href or '/banks/' in href:
                    bank_url = urljoin(BASE_URL, href)
                    banks.append((text, bank_url))

        # Heuristic deduplication: keep first occurrence per URL
        seen = set()
        unique: List[Tuple[str, str]] = []
        for name, url in banks:
            if url not in seen and self.is_probable_bank_name(name):
                seen.add(url)
                unique.append((name, url))

        if max_banks:
            unique = unique[:max_banks]

        logging.info(f"Found {len(unique)} bank links on state page: {state_url}")
        return unique

    @staticmethod
    def is_probable_bank_name(name: str) -> bool:
        name_l = name.lower()
        return any(k in name_l for k in [
            'bank', 'banc', 'savings', 'trust', 'financial', 'credit'
        ]) and len(name) > 3

    def discover_bank_branches(self, bank_url: str) -> List[Tuple[str, str]]:
        """Discover branch links on a bank page.
        Returns a list of (branch_name, branch_url).
        """
        soup = self.get(bank_url)
        if not soup:
            return []

        branches: List[Tuple[str, str]] = []
        selectors = [
            'a[href*="/branch/"]',
            'a[href*="/office/"]',
            'a[href*="/location/"]',
            'table a[href*="/branch"]',
        ]
        for sel in selectors:
            for a in soup.select(sel):
                href = a.get('href') or ''
                text = a.get_text(strip=True) or ''
                if not href or not text:
                    continue
                if any(k in href for k in ['/branch', '/office', '/location']):
                    branches.append((text, urljoin(BASE_URL, href)))

        # If none found, it may be an online-only bank or a bank with a single HQ listing
        # Try to parse a single address block on the bank page itself
        if not branches:
            addr_block = self.extract_address_block(soup)
            if addr_block:
                branches.append(("Headquarters", bank_url))

        # Deduplicate
        seen = set()
        unique: List[Tuple[str, str]] = []
        for name, url in branches:
            if url not in seen:
                seen.add(url)
                unique.append((name, url))
        return unique

    # --------------- Parsing helpers ---------------
    ADDRESS_RE = re.compile(r"^(?P<city>[A-Za-z .'-]+),\s*(?P<state>[A-Z]{2})\s*(?P<zip>\d{5}(?:-\d{4})?)$")
    PHONE_RE = re.compile(r"\(\d{3}\)\s*\d{3}-\d{4}")
    COUNTY_RE = re.compile(r"County:\s*(?P<county>[A-Za-z .'-]+)\b")

    def extract_address_block(self, soup: BeautifulSoup) -> Optional[Dict[str, str]]:
        # Try common classes
        for sel in ['.address', '.addr', 'address', '.branch-address', '.office-address']:
            node = soup.select_one(sel)
            if node and node.get_text(strip=True):
                text = " ".join(node.get_text(" ", strip=True).split())
                return {"raw": text}
        # Fallback: find any element that looks like an address (contains a comma and state abbreviation)
        for tag in soup.find_all(True):
            text = tag.get_text(" ", strip=True)
            if text and "," in text and any(f" {st} " in text for st in [
                ' AL ', ' AK ', ' AZ ', ' AR ', ' CA ', ' CO ', ' CT ', ' DE ', ' FL ', ' GA ', ' HI ', ' ID ', ' IL ', ' IN ', ' IA ', ' KS ', ' KY ', ' LA ', ' ME ', ' MD ', ' MA ', ' MI ', ' MN ', ' MS ', ' MO ', ' MT ', ' NE ', ' NV ', ' NH ', ' NJ ', ' NM ', ' NY ', ' NC ', ' ND ', ' OH ', ' OK ', ' OR ', ' PA ', ' RI ', ' SC ', ' SD ', ' TN ', ' TX ', ' UT ', ' VT ', ' VA ', ' WA ', ' WV ', ' WI ', ' WY '
            ]):
                return {"raw": " ".join(text.split())}
        return None

    def parse_branch_page(self, bank_name: str, branch_name: str, url: str) -> BranchRecord:
        soup = self.get(url)
        if not soup:
            return BranchRecord(bank_name, branch_name, '', '', '', '', '', 'No')

        # Address block parsing
        address_block = self.extract_address_block(soup)
        office_address = city_town = state_county = zip_code = ''
        if address_block:
            raw = address_block.get('raw', '')
            # Try to split into street and city/state/zip
            parts = [p.strip() for p in raw.split('\n') if p.strip()] if '\n' in raw else [p.strip() for p in raw.split('  ') if p.strip()]
            if len(parts) >= 2:
                street = parts[0]
                city_state_zip = parts[-1]
            else:
                # Heuristic: split by last comma
                if ',' in raw:
                    i = raw.rfind(',')
                    street = raw[:i].strip()
                    city_state_zip = raw[i+1:].strip()
                else:
                    street = raw
                    city_state_zip = ''
            office_address = street
            m = self.ADDRESS_RE.search(city_state_zip)
            if m:
                city_town = m.group('city')
                st = m.group('state')
                zip_code = m.group('zip')
                # County may be in the page elsewhere
                county = self.extract_county(soup)
                state_county = f"{st}, {county}" if county else st
            else:
                # Fallback to extracting any ZIP and STATE tokens
                zip_m = re.search(r"\b(\d{5}(?:-\d{4})?)\b", raw)
                st_m = re.search(r"\b([A-Z]{2})\b", raw)
                zip_code = zip_m.group(1) if zip_m else ''
                st = st_m.group(1) if st_m else ''
                county = self.extract_county(soup)
                state_county = f"{st}, {county}" if county else st
                # Try city as the token before state
                if st and ',' in raw:
                    before_state = raw.split(st)[0]
                    if ',' in before_state:
                        city_town = before_state.split(',')[-1].strip()

        # Phone
        phone_number = ''
        txt = soup.get_text(" ", strip=True)
        phone_m = self.PHONE_RE.search(txt)
        if phone_m:
            phone_number = phone_m.group(0)

        # Online bank detection: if no address and no branches found
        online = 'No'
        if not office_address and not city_town and not zip_code:
            online = 'Yes'

        return BranchRecord(
            bank_name=bank_name,
            branch_name=branch_name or 'Main Office',
            office_address=office_address,
            city_town=city_town,
            state_county=state_county,
            zip_code=zip_code,
            phone_number=phone_number,
            online_bank=online,
        )

    def extract_county(self, soup: BeautifulSoup) -> str:
        # Try labeled county fields
        # Common pattern like: "County: Cook"
        for sel in ['.county', 'li', 'p', 'div']:
            for node in soup.select(sel):
                text = node.get_text(" ", strip=True)
                m = self.COUNTY_RE.search(text)
                if m:
                    return m.group('county')
        # Fallback: look for "County" word near address areas
        text = soup.get_text(" ", strip=True)
        m = self.COUNTY_RE.search(text)
        return m.group('county') if m else ''


# --------------- Main crawling orchestration ---------------

def crawl_all(scraper: Scraper, max_states: Optional[int], max_banks: Optional[int]) -> Iterable[BranchRecord]:
    states = scraper.discover_state_links()
    if max_states:
        states = states[:max_states]

    for state_name, state_url in states:
        logging.info(f"State: {state_name} -> {state_url}")
        banks = scraper.discover_top_banks_on_state(state_url, max_banks=max_banks)
        if not banks:
            logging.warning(f"No banks discovered for state page: {state_url}")

        for bank_name, bank_url in banks:
            logging.info(f"  Bank: {bank_name} -> {bank_url}")
            branches = scraper.discover_bank_branches(bank_url)
            if not branches:
                logging.info(f"    No branches found, treating as online-only: {bank_name}")
                yield BranchRecord(bank_name, 'N/A', '', '', '', '', '', 'Yes')
                continue

            for branch_name, branch_url in branches:
                logging.debug(f"    Branch: {branch_name} -> {branch_url}")
                try:
                    rec = scraper.parse_branch_page(bank_name, branch_name, branch_url)
                except Exception as e:
                    logging.exception(f"Error parsing branch page {branch_url}: {e}")
                    rec = BranchRecord(bank_name, branch_name, '', '', '', '', '', 'No')
                yield rec


def write_csv(path: str, records: Iterable[BranchRecord]) -> int:
    headers = [
        'Bank Name', 'Branch Name', 'Office Address', 'City or Town',
        'State & County', 'Zip Code', 'Phone Number', 'Online Bank'
    ]
    count = 0
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(headers)
        for rec in records:
            w.writerow(rec.to_row())
            count += 1
    return count


def csv_to_xlsx(csv_path: str, xlsx_path: str) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.utils import get_column_letter
        import csv as _csv
        wb = Workbook()
        ws = wb.active
        ws.title = 'Banks'
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = _csv.reader(f)
            for r_idx, row in enumerate(reader, start=1):
                for c_idx, val in enumerate(row, start=1):
                    ws.cell(row=r_idx, column=c_idx, value=val)
        # Basic column sizing
        for col in range(1, 9):
            ws.column_dimensions[get_column_letter(col)].width = 24
        wb.save(xlsx_path)
    except Exception as e:
        logging.warning(f"Failed to write XLSX ({xlsx_path}). Ensure openpyxl installed. Error: {e}")


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description='Scrape BankBranchLocator top banks per state and branches')
    p.add_argument('--max-states', type=int, default=None)
    p.add_argument('--max-banks', type=int, default=None)
    p.add_argument('--delay', type=float, default=1.0)
    p.add_argument('--timeout', type=int, default=20)
    p.add_argument('--output', type=str, default='banks_all_states.csv')
    p.add_argument('--xlsx', type=str, default=None)
    p.add_argument('--log', type=str, default='INFO', help='Logging level (DEBUG, INFO, WARNING, ERROR)')
    args = p.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log.upper(), logging.INFO),
        format='%(asctime)s %(levelname)s: %(message)s'
    )

    scraper = Scraper(delay=args.delay, timeout=args.timeout)

    records = list(crawl_all(scraper, args.max_states, args.max_banks))
    logging.info(f"Total records collected: {len(records)}")

    n = write_csv(args.output, records)
    logging.info(f"Wrote CSV: {args.output} with {n} rows")

    if args.xlsx:
        csv_to_xlsx(args.output, args.xlsx)
        logging.info(f"Wrote XLSX: {args.xlsx}")

    logging.info('Done')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())